<?php
        $conn = mysqli_connect("localhost","root","","staff&faculty");
        
        
      
?>